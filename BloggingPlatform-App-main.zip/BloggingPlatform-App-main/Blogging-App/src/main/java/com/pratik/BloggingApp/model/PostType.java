package com.pratik.BloggingApp.model;

public enum PostType {
    TEXT,
    IMAGE,
    VIDEO


}
